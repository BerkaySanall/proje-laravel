    <div class="home_con">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <br>
                <h4>Sign Up
SIGN UP FOR NEWS & GET <b style="font-size: 23px;">15% OFF</b></h4>

            </div>
            <div class="col-md-6">
                <br>
                <input type="email" name="" placeholder="YOUR EMAIL ADDRESS" class="form-control">
            </div>
            <br><br><br><br>
            <p style="font-size: 14px;">By clicking the "Sign up" button, I confirm I am over 13 years of age.

Sign me up for the adidas emails, featuring exclusive offers, latest product info, news about upcoming events and more. Please see our <a href=""> Terms and Conditions</a>  and <a href="">Privacy Policy</a> Privacy Policy for more details. Selected products may be excluded from the 15% promotion.</p>
        </div>
    </div>
</div>

    <!-- FOOTER1 -->
    <div class="container">
        <footer class="pt-4 my-md-5 pt-md-5 border-top">
    <div class="row">
      <div class="col-6 col-md">
        <h5>Features</h5>
        <ul class="list-unstyled text-small">
          <li><a  href="/admin/login/">Admin Panel</a></li>
          <li><a  href="#">Random feature</a></li>
          <li><a  href="#">Team feature</a></li>
          <li><a href="#">Stuff for developers</a></li>
          <li><a  href="#">Another one</a></li>
          <li><a  href="#">Last time</a></li>
        </ul>
      </div>
      <div class="col-6 col-md">
        <h5>Features</h5>
        <ul class="list-unstyled text-small">
          <li><a  href="#">Cool stuff</a></li>
          <li><a href="#">Random feature</a></li>
          <li><a href="#">Team feature</a></li>
          <li><a href="#">Stuff for developers</a></li>
          <li><a href="#">Another one</a></li>
          <li><a href="#">Last time</a></li>
        </ul>
      </div>
      <div class="col-6 col-md">
        <h5>Resources</h5>
        <ul class="list-unstyled text-small">
          <li><a href="#">Resource</a></li>
          <li><a href="#">Resource name</a></li>
          <li><a href="#">Another resource</a></li>
          <li><a href="#">Final resource</a></li>
        </ul>
      </div>
      <div class="col-6 col-md">
        <h5>About</h5>
        <ul class="list-unstyled text-small">
          <li><a href="#">Team</a></li>
          <li><a href="#">Locations</a></li>
          <li><a href="#">Privacy</a></li>
          <li><a  href="#">Terms</a></li>
        </ul>
      </div>
    </div>
  </footer>
    </div>
    <style type="text/css">
        footer a{
            color: #000;
        }
        footer a:hover{
            color: #000;
        }
        .text-muted{
            font-size: 14px;

        }
        h5{
    font-weight: bold;
    font-size: 20px;
    text-transform: uppercase;
}
.home_con{
    height: 170px;
    background-color: #ede734;
    color: #000;
}
h4{
    font-weight: bold;
    font-size: 22px;
    text-transform: uppercase;
    font-family: 'adiBlack',Arial,Helvetica,Verdana,sans-serif;
}
    </style>
  <!-- FOOTER2 -->
  <footer class="container">
    <p class="float-right"><a href="#">Back to top</a></p>
    <p>&copy; 2017-2019 ACTIVESHOP, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
  </footer>

